/* 
 * File:   main.cpp
 * Author: Gavin Mullins
 * Created on January 9, 2017, 12:46 PM
 * Purpose:  Personal Information 
 */
  
//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"Gavin Mullins"<<endl<<"6395 Neva Place, Riverside, CA, 92506"<<endl<<"(951)206-4958"<<endl<<"Computer Programming"<<endl;

    //Exit
    return 0;
}

